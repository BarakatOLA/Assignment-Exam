CREATE TABLE screen (
    Screen_ID INT PRIMARY KEY,
    Four_K BOOLEAN
);

INSERT INTO screen 
(Screen_ID, Four_K)
VALUES (1, FALSE);