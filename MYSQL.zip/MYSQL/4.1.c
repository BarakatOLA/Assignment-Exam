CREATE TABLE showings (
    Showing_ID INT PRIMARY KEY,
    Movie_ID INT,
    Screen_ID INT,
    Start_Time TIME,
    Available_Seats INT
);

INSERT INTO showings 
(Showing_ID, Movie_ID, Screen_ID, Start_Time, Available_Seats)
VALUES (1, 1, 1, '12:00:00', 23);